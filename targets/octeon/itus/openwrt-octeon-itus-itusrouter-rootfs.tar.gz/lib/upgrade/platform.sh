#
# Copyright (C) 2014 OpenWrt.org
#

platform_get_rootfs() {
	local rootfsdev

	if read cmdline < /proc/cmdline; then
		case "$cmdline" in
			*block2mtd=*)
				rootfsdev="${cmdline##*block2mtd=}"
				rootfsdev="${rootfsdev%%,*}"
			;;
			*root=*)
				rootfsdev="${cmdline##*root=}"
				rootfsdev="${rootfsdev%% *}"
			;;
		esac

		echo "${rootfsdev}"
	fi
}

platform_copy_config() {
	case "$(board_name)" in
	erlite)
		mount -t vfat /dev/sda1 /mnt
		cp -af "$UPGRADE_BACKUP" "/mnt/$BACKUP_FILE"
		umount /mnt
		;;
	itus)
		mount -t vfat /dev/mmcblk1p1 /mnt
                cp -af "$UPGRADE_BACKUP" "/mnt/$BACKUP_FILE"
                umount /mnt
		;;
	esac
}

platform_do_flash() {
	local tar_file=$1
	local board=$2
	local kernel=$3
	local rootfs=$4

	mkdir -p /boot
	mount -t vfat /dev/$kernel /boot

	[ -f /boot/vmlinux.64 -a ! -L /boot/vmlinux.64 ] && {
		mv /boot/vmlinux.64 /boot/vmlinux.64.previous
		mv /boot/vmlinux.64.md5 /boot/vmlinux.64.md5.previous

        	echo "flashing kernel to /dev/$kernel"
        	md5sum /boot/vmlinux.64 | cut -f1 -d " " > /boot/vmlinux.64.md5
	        echo "flashing rootfs to ${rootfs}"
	}

        case "$board" in
        er | erlite)
           tar xf $tar_file sysupgrade-$board/kernel -O > /boot/vmlinux.64
           tar xf $tar_file sysupgrade-$board/root -O | dd of="${rootfs}" bs=4096
                ;;
        itus*)
	   tar xvzf $tar_file -C /tmp
	   echo "Moving kernel image..."
	   cp -v /tmp/sysupgrade-$board/kernel /boot/${kernel}
	   echo "Flashing rootfs..."
	   dd if=/tmp/sysupgrade-$board/root of=/dev/${rootfs} bs=512
                ;;
        esac

	sync
	umount /boot
}

platform_do_upgrade() {
	local tar_file="$1"
	local board=$(board_name)
	local rootfs="$(platform_get_rootfs)"
	local kernel=

	[ -b "${rootfs}" ] || return 1
	case "$board" in
	er)
		kernel=mmcblk0p1
		;;
	erlite)
		kernel=sda1
		;;
	itusrouter)
		kernel=ItusrouterImage
		;;
	itusbridge)
		kernel=ItusbridgeImage
		;;
	*)
		return 1
	esac

	platform_do_flash $tar_file $board $kernel $rootfs

	return 0
}

platform_check_image() {
	local board=$(board_name)

	case "$board" in
	er | erlite)
		local tar_file="$1"
		local kernel_length=$(tar xf $tar_file sysupgrade-$board/kernel -O | wc -c 2> /dev/null)
		local rootfs_length=$(tar xf $tar_file sysupgrade-$board/root -O | wc -c 2> /dev/null)
		[ "$kernel_length" = 0 -o "$rootfs_length" = 0 ] && {
			echo "The upgrade image is corrupt."
			return 1
		}
		return 0
	;;
	itus*)
		local tar_file="$1"
		# Remove any existing, just in case...
		tar xvfz $tar_file -C /tmp
		echo "$board - $tar_file"
		if [ ! -f /tmp/sysupgrade-itus*/kernel ] || [ ! -f /tmp/sysupgrade-itus*/root ]
		then
                        echo "The upgrade image is corrupt."
                        return 1
                fi
		return 0
	;;
	esac

	echo "Sysupgrade is not yet supported on $board."
	return 1
}
